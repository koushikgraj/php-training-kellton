<title>Access not granted</title>
<img src="https://freefrontend.com/assets/img/403-forbidden-html-templates/html-access-not-granted.png" style="width:100%;">