<?php

	return [
'site_name'=>'Electronic Store'
	];