
<?php $__env->startSection('page_title','Manage Product'); ?>
<?php $__env->startSection('product_select','active'); ?>
<?php $__env->startSection('container'); ?>

<?php if($id>0): ?>
    <?php echo e($image_required=""); ?>

<?php else: ?>
    <?php echo e($image_required="required"); ?>

<?php endif; ?>

    <h1 class="mb10">Manage Product</h1>
    <a href="<?php echo e(url('admin/product')); ?>">
        <button type="button" class="btn btn-success">
            Back
        </button>
    </a>
    <div class="row m-t-30">
        <div class="col-md-12">
        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('product.manage_product_process')); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1"> Name</label>
                                                <input id="name" value="<?php echo e($name); ?>" name="name" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>		
                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="slug" class="control-label mb-1"> Slug</label>
                                                <input id="slug" value="<?php echo e($slug); ?>" name="slug" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger" role="alert">
                                                    <?php echo e($message); ?>		
                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
<div class="form-group">
    <label for="image" class="control-label mb-1"> Image</label>
    <input id="image" name="image" type="file" class="form-control" aria-required="true" aria-invalid="false" <?php echo e($image_required); ?>>
    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e($message); ?>		
    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
    <label for="category_id" class="control-label mb-1"> Category</label>
    <select id="category_id" name="category_id" class="form-control" required>
        <option value="">Select Categories</option>
        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($category_id==$list->id): ?>
                <option selected value="<?php echo e($list->id); ?>">
            <?php else: ?>
                <option value="<?php echo e($list->id); ?>">
            <?php endif; ?>
            <?php echo e($list->category_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label for="brand" class="control-label mb-1"> Brand</label>
    <input id="brand" value="<?php echo e($brand); ?>" name="brand" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
</div>

<div class="form-group">
    <label for="model" class="control-label mb-1"> Model</label>
    <input id="model" value="<?php echo e($model); ?>" name="model" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
</div>

<div class="form-group">
    <label for="short_desc" class="control-label mb-1"> Short Desc</label>
    <textarea id="short_desc" name="short_desc" type="text" class="form-control" aria-required="true" aria-invalid="false" required><?php echo e($short_desc); ?></textarea>
</div>

<div class="form-group">
    <label for="desc" class="control-label mb-1"> Desc</label>
    <textarea id="desc" name="desc" type="text" class="form-control" aria-required="true" aria-invalid="false" required><?php echo e($desc); ?></textarea>
</div>

<div class="form-group">
    <label for="keywords" class="control-label mb-1"> Keywords</label>
    <textarea id="keywords" name="keywords" type="text" class="form-control" aria-required="true" aria-invalid="false" required><?php echo e($keywords); ?></textarea>
</div>

<div class="form-group">
    <label for="technical_specification" class="control-label mb-1"> Technical Specification</label>
    <textarea id="technical_specification" name="technical_specification" type="text" class="form-control" aria-required="true" aria-invalid="false" required><?php echo e($technical_specification); ?></textarea>
</div>

<div class="form-group">
    <label for="uses" class="control-label mb-1"> Uses</label>
    <textarea id="uses" name="uses" type="text" class="form-control" aria-required="true" aria-invalid="false" required><?php echo e($uses); ?></textarea>
</div>

<div class="form-group">
    <label for="warranty" class="control-label mb-1"> Warranty</label>
    <textarea id="warranty" name="warranty" type="text" class="form-control" aria-required="true" aria-invalid="false" required><?php echo e($warranty); ?></textarea>
</div>

                                            <div>
                                                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                    Submit
                                                </button>
                                            </div>
                                            <input type="hidden" name="id" value="<?php echo e($id); ?>"/>
                                        </form>
                                    </div>
                                </div>
                            </div>
                           
                           
                            
                            
                            
                            
                        </div>
                        
        </div>
    </div>
                        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\php-training-kellton\AJAY\INTERNAL-Project-Team1\INTERNAL-Project-Team1\resources\views\admin\manage_product.blade.php ENDPATH**/ ?>