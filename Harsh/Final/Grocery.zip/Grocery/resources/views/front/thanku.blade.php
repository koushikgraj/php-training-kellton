@extends('front.layout.layout')
@section('content')
<div class="span4" style="padding-left:250px;">
			<div class="well">
			<h2>THANKYOU FOR SHOPPING</h2><br>
			Love from G3<br><br><br>
			
		</div>
		</div>
		<a href="{{route('home')}}"><button type="submit" class="btn block">GO BACK</button></a>
@endsection