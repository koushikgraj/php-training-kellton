<!-- Sidebar ================================================== -->
<!-- <div id="sidebar" class="span3">
		<div class="well well-small"><a id="myCart" href="<?php echo e(route('cart')); ?>"><img src="themes/images/ico-cart.png" alt="cart"> Items in your cart  <span class="badge badge-warning pull-right"></span></a></div>
		<ul id="sideManu" class="nav nav-tabs nav-stacked">
			<li class="subMenu open"><a>ATTA,RICE & DAL [250]</a>
				<ul>
				<li><a class="active" href="products.html"><i class="icon-chevron-right"></i>Dal(100) </a></li>
				<li><a href="products.html"><i class="icon-chevron-right"></i>Rajma Chawal(30)</a></li>
				<li><a href="products.html"><i class="icon-chevron-right"></i>Poha(80)</a></li>
				<li><a href="products.html"><i class="icon-chevron-right"></i>Maida (15)</a></li>
				</ul>
			</li>
			<li class="subMenu"><a> MASALA,OIL [840] </a>
			<ul style="display:none">
				<li><a href="products.html"><i class="icon-chevron-right"></i>Ghee (45)</a></li>
				<li><a href="products.html"><i class="icon-chevron-right"></i>Dry Fruits (8)</a></li>												
				<li><a href="products.html"><i class="icon-chevron-right"></i>Species (5)</a></li>	
				<li><a href="products.html"><i class="icon-chevron-right"></i>Herbs  (45)</a></li>
				<li><a href="products.html"><i class="icon-chevron-right"></i>Salt (6)</a></li>												
				<li><a href="products.html"><i class="icon-chevron-right"></i>Sugar (5)</a></li>												
				<li><a href="products.html"><i class="icon-chevron-right"></i>Masala (3)</a></li>												
			</ul>
			</li>
			<li class="subMenu"><a>SNACKS[1000]</a>
				<ul style="display:none">
				<li><a href="products.html"><i class="icon-chevron-right"></i>Biscuits  (35)</a></li>
				<li><a href="products.html"><i class="icon-chevron-right"></i>Chips (8)</a></li>												
				<li><a href="products.html"><i class="icon-chevron-right"></i>Noodles (5)</a></li>	
				<li><a href="products.html"><i class="icon-chevron-right"></i>Chochos (45)</a></li>
				<li><a href="products.html"><i class="icon-chevron-right"></i>Corn (8)</a></li>												
															
			</ul>
			</li>
			<li><a href="products.html">HEALTH & BEAUTY [18]</a></li>
			<li><a href="products.html">BABY CARE [58]</a></li>
			<li><a href="products.html">HOME & KITCHEN [14]</a></li>
		</ul>
		<br/>
		  <div class="thumbnail">
			<img src="<?php echo e(asset('themes/images/products/b5.webp')); ?>" alt="Bootshop panasonoc New camera"/>
			<div class="caption">
			  <h5>Family Pack</h5>
				<h4 style="text-align:center"><a class="btn" href="product_details.html"> <i class="icon-zoom-in"></i></a> <a class="btn" href="#">Add to <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">$222.00</a></h4>
			</div>
		  </div><br/>
			<div class="thumbnail">
				<img src="<?php echo e(asset('themes/images/products/b6.webp')); ?>" title="Bootshop New Kindel" alt="Bootshop Kindel">
				<div class="caption">
				  <h5>Family Pack</h5>
				    <h4 style="text-align:center"><a class="btn" href="product_details.html"> <i class="icon-zoom-in"></i></a> <a class="btn" href="#">Add to <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">$222.00</a></h4>
				</div>
			  </div><br/>
			<div class="thumbnail">
				<img src="<?php echo e(asset('themes/images/payment_methods.png')); ?>" title="Bootshop Payment Methods" alt="Payments Methods">
				<div class="caption">
				  <h5>Payment Methods</h5>
				</div>
			  </div>
	</div> -->
<!-- Sidebar end=============================================== --><?php /**PATH C:\xampp\htdocs\practice.php\php-training-kellton\Harsh\Final\Grocery\resources\views/front/layout/sidebar.blade.php ENDPATH**/ ?>