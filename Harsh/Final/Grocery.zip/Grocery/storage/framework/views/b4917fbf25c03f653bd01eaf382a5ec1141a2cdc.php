<div id="header">
<div class="container">
<div id="welcomeLine" class="row">
<?php if(Auth::user()): ?>

	<div class="span6">Welcome!<strong> <?php echo e(Auth::user()->name); ?></strong></div>

	<?php else: ?>
	<div class="span6">Welcome!<strong> Please Login</strong></div>
	<?php endif; ?>
	
	<div class="span6">
	<div class="pull-right">
		
		<a href="<?php echo e(route('cart')); ?>"><span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i> Itemes in your cart </span> </a> 
	</div>
	</div>
</div>
<!-- Navbar ================================================== -->
<div id="logoArea" class="navbar">
<a id="smallScreen" data-target="#topMenu" data-toggle="collapse" class="btn btn-navbar">
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
</a>
  <div class="navbar-inner">
    <a class="brand" ><img src="themes/images/logo.png" alt="Bootsshop"/></a>
		<!-- <form class="form-inline navbar-search" method="post" action="products.html" >
		<input id="srchFld" class="srchTxt" type="text" /> -->
		  
		  <button type="submit" id="submitButton" class="btn btn-primary" style="margin-left:60px;">Made with Love By Harsh Gopal & Sandy Guided By Ankur Mittal Sir</button>
		  <!-- <button type="submit" id="submitButton" class="btn btn-primary">Enjoyed Working in this project</button> -->
    </form>
    <ul id="topMenu" class="nav pull-right">
	 <li class=""><a href="<?php echo e(route('specialOffer')); ?>">Specials Offer</a></li>
	 <li class=""><a href="<?php echo e(route('delivery')); ?>">Delivery</a></li>
	 <li class=""><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
	 <li class="">
		<?php if(Auth::user()): ?>
	 <a href="<?php echo e(route('user_logout')); ?>" ><span class="btn btn-large btn-success">Logout</span></a>
	 <?php else: ?>
	 <a href="<?php echo e(route('user_login')); ?>" ><span class="btn btn-large btn-success">Login</span></a>
	 <?php endif; ?>
	</li>
    </ul>
  </div>
</div>
</div>
</div>
<!-- Header End====================================================================== --><?php /**PATH C:\xampp\htdocs\practice.php\php-training-kellton\Harsh\Final\Grocery\resources\views/front/layout/header.blade.php ENDPATH**/ ?>