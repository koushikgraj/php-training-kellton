
<?php $__env->startSection('content'); ?>
<div class="span4" style="padding-left:250px;">
			<div class="well">
			<h3>PAYMENT METHOD</h3><br>
			Cash On Delivery Method Only Available<br><br><br>
			<form action="<?php echo e(route('booked.store')); ?>" method="post">
				<?php echo csrf_field(); ?>
			  <div class="control-group">
				<label class="control-label" for="inputEmail0">Name</label>
				<div class="controls">
				  <input class="span3" type="text" name="name" id="inputEmail0" placeholder="Enter your name" required>
				</div>
			  </div>
			  <div class="control-group">
				<label class="control-label" for="inputEmail0">Phone Number</label>
				<div class="controls">
				  <input class="span3" type="text" name="phone_number" id="inputEmail0" placeholder="Enter your phone" required>
				</div>
			  </div>
			  <div class="control-group">
				<label class="control-label" for="inputEmail0">Address</label>
				<div class="controls">
				  <input class="span3" type="text" name="address" id="inputEmail0" placeholder="Enter your address" required>
				</div>
			  </div>
			  <h5><input type="checkbox" required>Cash On delivery</h5>
			  <div class="controls">
			  <a href="<?php echo e(route('user_thanku')); ?>"><button type="submit" class="btn block">CONTINUE</button></a>
			  </div>
			</form>
			
		</div>
		</div>
		<a href="<?php echo e(route('home')); ?>"><button type="submit" class="btn block">GO BACK</button></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice.php\php-training-kellton\Harsh\Final\Grocery\resources\views/front/payment.blade.php ENDPATH**/ ?>