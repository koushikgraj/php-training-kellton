
<?php $__env->startSection('content'); ?>
<div class="span4" style="padding-left:250px;">
			<div class="well">
			<h2>THANKYOU FOR SHOPPING</h2><br>
			Love from G3<br><br><br>
			
		</div>
		</div>
		<a href="<?php echo e(route('home')); ?>"><button type="submit" class="btn block">GO BACK</button></a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice.php\php-training-kellton\Harsh\Final\Grocery\resources\views/front/thanku.blade.php ENDPATH**/ ?>