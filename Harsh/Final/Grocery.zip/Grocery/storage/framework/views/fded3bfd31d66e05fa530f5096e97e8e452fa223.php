
<?php $__env->startSection('content'); ?>
<div class="span9">
    <ul class="breadcrumb">
		<li><a href="index.html">Home</a> <span class="divider">/</span></li>
		<li class="active">Login</li>
    </ul>
	<h3> Login</h3>	

			<div class="well">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
		
			<form class="form-horizontal" method="post" action="<?php echo e(route('loginCheck')); ?>">
                <?php echo csrf_field(); ?>
			  <div class="control-group">
				<label class="control-label" for="inputEmail1">Email</label>
				<div class="controls">
				  <input class="span3"  type="text" name="email" id="inputEmail1" placeholder="Email">
				</div>
			  </div>
			  <div class="control-group">
				<label class="control-label" for="inputPassword1">Password</label>
				<div class="controls">
				  <input type="password"  name="password" class="span3"  id="inputPassword1" placeholder="********">
				</div>
			  </div>
			  <div class="control-group">
				<div class="controls">
				  <button type="submit" class="btn">Login</button> <a href="forgetpass.html">Forget password?</a>
				</div>
			  </div>
			</form>
		</div>
		</div>
        <div class="span9">
    <ul class="breadcrumb">
		
    </ul>
	<h3>Registration</h3>	

			<div class="well">
		
			<form class="form-horizontal" action="<?php echo e(route('user_store')); ?>" method="post">
                <?php echo csrf_field(); ?>
			  <div class="control-group">
				<label class="control-label" for="inputEmail1">First Name</label>
				<div class="controls">
				  <input class="span3"  type="text" name="first_name" id="inputfname" placeholder="First Name" required>
				</div>
			  </div>
			  <div class="control-group">
				<label class="control-label" for="inputEmail1">Last Name</label>
				<div class="controls">
				  <input class="span3"  type="text" name="last_name" id="inputlname" placeholder="Last Name" required>
				</div>
			  </div>
			  <div class="control-group">
				<label class="control-label" for="inputEmail1">Email</label>
				<div class="controls">
				  <input class="span3"  type="email" name="email" id="inputEmail1" placeholder="Email" required>
				</div>
			  </div>
			  <div class="control-group">
				<label class="control-label" for="inputPassword1">Password</label>
				<div class="controls">
				  <input type="password" class="span3"  name="password"id="inputPassword1" placeholder="********" required>
				</div>
			  </div>
			  <div class="control-group">
				<div class="controls">
				  <button type="submit" class="btn">Submit</button>
				</div>
			  </div>
			</form>
		</div>
		</div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice.php\php-training-kellton\Harsh\Final\Grocery\resources\views/front/login.blade.php ENDPATH**/ ?>