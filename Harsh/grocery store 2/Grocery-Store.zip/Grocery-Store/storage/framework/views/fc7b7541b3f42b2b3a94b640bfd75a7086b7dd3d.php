
<?php $__env->startSection('content'); ?>
<table class="table table-striped table-bordered">
    <thead>
        <tr>
            <th>S.no</th>
            <th>Product Name</th>
            <th>Category Name</th>
            <th>Price</th>
            <th>Image</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key+1); ?></td>
            <td><?php echo e($product->name); ?></td>
            <td>
                <?php if($product->category_id): ?>
                <?php echo e($product->category->name); ?>

                <?php endif; ?>
            </td>
            <td><?php echo e($product->price); ?></td>
            
            <td><img style="height:80px;widht:80px:" src="<?php echo e(asset('/uploads/'.$product->image)); ?>" alt=""></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice.php\php-training-kellton\Harsh\grocery store 2\Grocery-Store\resources\views/admin/product/index.blade.php ENDPATH**/ ?>