
<?php $__env->startSection('content'); ?>
<table class="table">
    <thead>
        <tr>
            <th>S.no</th>
            <th>Category Name</th>
            <th>Parent Category Name</th>
            <th>Create Date</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key+1); ?></td>
            <td><?php echo e($categorie->name); ?></td>
            <td>
                <?php if($categorie->category_id): ?>
                <?php echo e($categorie->parent->name); ?>

                <?php else: ?>
                No Parent Category
                <?php endif; ?>
            </td>
            <td><?php echo e($categorie->created_at); ?></td>
            <td><a href="<?php echo e(route('category.edit',$categorie->id)); ?>"><i class="fa fa-edit"></i></a>
            <a href=""><i class="fa fa-trash"></i></a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice.php\php-training-kellton\Harsh\grocery store 2\Grocery-Store\resources\views/admin/category/index.blade.php ENDPATH**/ ?>