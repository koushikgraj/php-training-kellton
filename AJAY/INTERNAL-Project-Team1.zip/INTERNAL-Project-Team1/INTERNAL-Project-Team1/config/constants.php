<?php

	return [
'SITE_NAME'=>'My Ecom'
	];