

<?php $__env->startSection('container'); ?>

<div class="row">
    <h1>Dashboard</h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\php-training-kellton\AJAY\INTERNAL-Project-Team1\INTERNAL-Project-Team1\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>