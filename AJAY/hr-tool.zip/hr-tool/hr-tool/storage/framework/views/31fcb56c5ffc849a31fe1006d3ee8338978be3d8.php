
<?php $__env->startSection('content'); ?>



<!DOCTYPE html>
<?php
    $user_id = Session::get('user_id');

?>





    <form action="<?php echo e(url('store-timesheet')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <table class="table table-bordered table-dark" id="table">
            <thead>
              <tr>
                <th scope="col">User_id</th>
                <th scope="col">Date</th>
                <th scope="col">Start time</th>
                <th scope="col">End time</th> 
                <th scope="col">Regular Hours</th>
                <th scope="col">Over Time</th>
                <th scope="col">Total Hours</th>

              </tr>
            </thead>
            <tbody>
              <tr>
                <td><input type="text" name="userid" value="<?php echo e($user_id); ?>" readonly></td>
                <th scope="row"><input type="Date" name="date"></th>
                <td><input type="time" name="start"></td>
                <td><input type="time" name="end"></td>
                <td><input type="text" name="regulartime"></td>
                <td><input type="text" name="overtime"></td>
                <td><input type="text"name="totalhours"></td>
              </tr>
      
            </tbody>

            <tbody>
              <tr>
                <td style="color: red"><?php $__errorArgs = ['userid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                <td style="color: red"><?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td><br>
                <td style="color: red"><?php $__errorArgs = ['start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td><br>
                <td style="color: red"><?php $__errorArgs = ['end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td><br>
                <td style="color: red"><?php $__errorArgs = ['regulartime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td><br>
                <td style="color: red"><?php $__errorArgs = ['overtime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td><br>
                <td style="color: red"><?php $__errorArgs = ['totalhours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td><br>


              </tr>
            </tbody>

              
          </table>
          
          <button type="submit" class="btn btn-secondary" >Submit</button>


      
    </form>
    <br><br> 
    <table id="myTables" class="table table-bordered table-dark">
      <thead>
        <tr>
          <th scope="col">User_id</th>
          <th scope="col">Date</th>
          <th scope="col">Start time</th>
          <th scope="col">End time</th> 
          <th scope="col">Regular Hours</th>
          <th scope="col">Over Time</th>
          <th scope="col">Total Hours</th>

        </tr>
      </thead>

      <tbody id = "myrow">
    
      </tbody>
    </table>
   
    

     <script>
        var ajax = new XMLHttpRequest();
        var method = "GET";
        var url = "get-timesheet";
        var asynchronous = true;
        ajax.open(method, url, asynchronous);
        ajax.send();
        ajax.onreadystatechange = function(){
            if(this.readyState===4 && this.status===200 ){
              let data = JSON.parse(this.responseText);
              console.log(data);  
              
              let x = document.getElementById("myrow");
          

              for(let i=0;i<data.length;i++){
                let tr = document.createElement('tr');
                let obj = data[i];
                for(const key in obj){
                if(key === "created_at" || key ==="updated_at" || key === "id"){
                  continue;
                }  
                let td = document.createElement('td');
                if(key === "regular"){
                
                td.textContent = obj[key];
                let temp = Number(td.textContent);
                if(temp<8){
                  td.style.backgroundColor = 'red';
                }
                tr.appendChild(td);
                }
                else{
                    td.textContent = obj[key];
                    tr.appendChild(td);
                }
                }
                x.appendChild(tr);

              }
            

            }
        }

      </script> 


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\php-training-kellton\AJAY\hr-tool\hr-tool\resources\views/timesheet.blade.php ENDPATH**/ ?>