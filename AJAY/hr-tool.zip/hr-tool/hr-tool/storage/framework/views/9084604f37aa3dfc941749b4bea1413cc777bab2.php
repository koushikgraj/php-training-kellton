
<?php $__env->startSection('content'); ?>
<form action ="<?php echo e(url('store-attendance')); ?>" method="POST">
<?php echo csrf_field(); ?>

<div class="head">
        <h1>Attendance</h1>
        <h2>Dashboard/Attendance</h2>
    </div>

    <table class ="table" id=" ">
    <tbody id="myrow">
  <div class="form-group" >
    <label for="formGroupExampleInput">First Name</label>
    <input type="text" name ="first_name" class="form-control" id="formGroupExampleInput" placeholder="Enter fisrt name" required>
  </div>
  <br>
  <div>
  <label for="formGroupExampleInput">Last Name </label>
    <input type="text" name ="last_name" class="form-control" id="formGroupExampleInput" placeholder="Enter last name"required>
  </div>
  <br>
  <div>
  <label for="formGroupExampleInput">Employee Id</label>
    <input type="text" name ="emp_id" class="form-control" id="formGroupExampleInput" placeholder="Enter employee id"required>
  </div>
    <div>
  <label for="formGroupExampleInput">Status :</label>

  <select name="status" id="" >
  <option selected>Select</option>
              <option >P</option>
              <option >A</option>
</select>
  </select>
  <input type  = "submit" name= "btnsubmit" value="submit">

</div>
</tbody>
</table>


  



</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\php-training-kellton\AJAY\hr-tool\hr-tool\resources\views/attendance.blade.php ENDPATH**/ ?>