
<?php $__env->startSection('content'); ?>

<form action="<?php echo e(url('updateholiday')); ?>/<?php echo e($holiday->id); ?>" method="post" >
<!-- <form action ="store" method="POST"> -->
<?php echo csrf_field(); ?>

<div class="choliday">

  <div>
  <!--<label for="formGroupExampleInput">Month</label>
    <input type="text" value ="<?php echo e($holiday->month); ?>" name ="month" class="form-control" id="formGroupExampleInput" placeholder="Enter Month">
  </div>
  <br>-->
  <input type="hidden" name="id" value="<?php echo e($holiday->id); ?>">
  <div>
  <label for="formGroupExampleInput">Date</label>
    <input type="date" value ="<?php echo e($holiday->date); ?>" name ="date" class="form-control" id="formGroupExampleInput" placeholder="Enter Date">
  </div>
<!--<div>
   <label for="formGroupExampleInput">Day of Week</label>
    <input type="text" value ="<?php echo e($holiday->day_of_the_week); ?>" name ="dayweek" class="form-control" id="formGroupExampleInput" placeholder="Enter Week">
  </div>-->
  <div>
   <label for="formGroupExampleInput">Holiday</label>
    <input type="text" value ="<?php echo e($holiday->holiday); ?>" name ="holiday" class="form-control" id="formGroupExampleInput" placeholder="Enter Holiday">
  </div>
  <div>
  <label for="formGroupExampleInput">Holiday Type</label>
    <input type="text" value ="<?php echo e($holiday->holiday_type); ?>"name ="holidaytype" class="form-control" id="formGroupExampleInput" placeholder="Enter Holiday Type">
  </div>
  <br>
  
  <input type  = "submit" name= "btnsubmit" value="submit">
</div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\php-training-kellton\AJAY\hr-tool\hr-tool\resources\views/editholiday.blade.php ENDPATH**/ ?>