
<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="mystyle.css">
</head>

<body style="background-color:powderblue;">

</style>
<h6>Choose a Filter</h6> 

<select class="selectpicker">
  <option>2015</option>
  <option>2016</option>
  <option>2017</option>
  <option>2018</option>
  <option>2019</option>
  <option>2020</option>
  <option>2021</option>
  <option>2022</option>
  
</select>
<button class="btn btn-primary" type="submit">Find Values</button>
 
<a href ="<?php echo e(url('createholiday')); ?>"class="btn btn-primary">Add Holiday</a>




<section>

<h3>Holiday Schedule-2022</h3>

    <table class ="table" >

    <thead class="table-light">
    <tr>
      <th scope="col">S.No</th>
      <th scope="col">Month</th>
      <th scope="col">Date</th>
      <th scope="col">Day of the week</th>
      <th scope="col">Holiday</th>
      <th scope="col">Holiday type</th>
      <th width="col">Action</th>
    </tr>
  </thead>


  <tbody id="myrow">

<?php
$i=0;
?>     
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
  <td><?php echo ++$i;?></td>
  <td><?php echo date('M',strtotime($item->date));?></td>
  <td><?php echo e($item->date); ?></td>
  <td><?php echo date('l',strtotime($item->date));?></td>
  <td><?php echo e($item->holiday); ?></td>
  <td><?php echo e($item->holiday_type); ?></td>

  <td>
  <!-- Edit -->
  <a href='<?php echo e(url("editholiday/$item->id")); ?>' class="btn btn-sm btn-info">Edit</a>
  <!-- Delete -->
  <a href='<?php echo e(url("deleteholiday/$item->id")); ?>' class="btn btn-sm btn-danger">Delete</a>
  </td>


 
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
  

    
</table>

</section>
<script>



</script>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\php-training-kellton\AJAY\hr-tool\hr-tool\resources\views/holiday.blade.php ENDPATH**/ ?>