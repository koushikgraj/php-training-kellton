@extends('layout')
@section('content')


<p style="color:white;"> Therre is some sample content.</p>
@endsection