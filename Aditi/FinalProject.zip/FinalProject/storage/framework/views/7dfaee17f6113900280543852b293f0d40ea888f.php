
<?php $__env->startSection('content'); ?>
<style>
    .card-title{
        color: black;
    }
    .col-sm-3{
    margin-left: 230px;
    margin-bottom: 50px
    }
    .fas {
        color: black;
        font-size: 72px;

    }
    /* .card-body{
        padding-left: 100px;
    } */
</style>
<br><br><br><br>
<div class="row">
  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <center>
      <i class="fas fa-rupee-sign"></i>
        <h1 class="card-title" >Earned </h1>
        <!-- <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> -->
        <a href="#" class="btn btn-primary">Apply</a>
      </div>
      </center>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <center>
      <i class="fas fa-walking"></i>
        <h1 class="card-title">Casual </h1>
        <!-- <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> -->
        <a href="#" class="btn btn-primary">Apply</a>
      </div>
      </center>
    </div>
  </div>
</div>
<br><br><br><br><br>
<div class="row">
  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <center>
      <i class="fas fa-hand-holding-usd"></i>
        <h1 class="card-title">L-W-P </h1>
        <!-- <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> -->
        <a href="#" class="btn btn-primary">Apply</a>
      </div>
      </center>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <center>
      <i class="fas fa-stamp"></i>
        <h1 class="card-title">L-O-P </h1>
        <!-- <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> -->
        <a href="#" class="btn btn-primary">Apply</a>
      </div>
      </center>
    </div>
  </div>
</div>
<br><br><br><br><br>
<div class="row">
  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <center>
      <i class="fas fa-ring"></i>
        <h1 class="card-title">Marraige </h1>
        <!-- <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> -->
        <a href="#" class="btn btn-primary">Apply</a>
      </div>
      </center>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <center>
      <i class="fas fa-hourglass-start"></i>
        <h1 class="card-title">Bereavement</h1>
        
        <!-- <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> -->
        <a href="#" class="btn btn-primary">Apply</a>
      </div>
      </center>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice.php\php-training-kellton\Harsh\dffgd\FinalProject\resources\views/applys.blade.php ENDPATH**/ ?>