
<?php $__env->startSection('content'); ?>


<div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>User:</strong>
                <?php echo e($leave->user); ?>

            </div>
        </div>
        <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>ltype:</strong>
                <?php echo e($leave->ltype); ?>

            </div>
        </div>
        <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Starting_date:</strong>
                <?php echo e($leave->sdate); ?>

            </div>
        </div>
        <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>End_date:</strong>
                <?php echo e($leave->edate); ?>

            </div>
        </div>
        <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Reason:</strong>
                <?php echo e($leave->reason); ?>

            </div>
        </div>
              
        <button type="button" class="btn btn-secondary">Approved</button>
        <button type="button" class="btn btn-secondary">Dis Approved</button>
        <button type="button" class="btn btn-secondary">Hold</button>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice\php-training-kellton\Aditi\FinalProject\resources\views/view-details.blade.php ENDPATH**/ ?>