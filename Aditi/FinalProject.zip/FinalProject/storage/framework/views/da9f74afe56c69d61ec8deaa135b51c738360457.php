
<?php $__env->startSection('content'); ?>


<p style="color:white;"> Therre is some sample content.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice\php-training-kellton\Aditi\FinalProject\resources\views/sample.blade.php ENDPATH**/ ?>